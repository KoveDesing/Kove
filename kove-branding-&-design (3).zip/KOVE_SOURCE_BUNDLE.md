# KOVE PREMIUM BRANDING - PROJECT BUNDLE

Este documento contiene el código completo y la estructura necesaria para replicar la web de KOVE.

## 1. Dependencias Necesarias (package.json)
Para que todo funcione, asegúrate de tener estas librerías instaladas:
- `react`, `react-dom` (v19)
- `motion` (v12)
- `lucide-react`
- `lenis` (Smooth scroll)
- `clsx`, `tailwind-merge` (Utilidades CSS)
- `tailwindcss` (v4)

## 2. Estructura de Archivos

### Archivo: `src/lib/utils.ts`
```typescript
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

### Archivo: `src/index.css`
```css
@import url('https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Outfit:wght@100..900&display=swap');
@import "tailwindcss";

@theme {
  --font-sans: "Inter", ui-sans-serif, system-ui, sans-serif;
  --font-display: "Outfit", sans-serif;
  
  --color-titanium: #050505;
  --color-titanium-light: #111111;
  --color-glass: rgba(255, 255, 255, 0.03);
  --color-glass-border: rgba(255, 255, 255, 0.08);
  --color-apple-text: #F5F5F7;
}

@layer base {
  body {
    @apply bg-titanium text-apple-text antialiased selection:bg-white selection:text-black;
    background: radial-gradient(circle at 50% 50%, #111111 0%, #050505 100%);
  }
}

.glass {
  @apply backdrop-blur-2xl bg-glass border border-glass-border shadow-2xl;
}

.text-gradient {
  @apply bg-clip-text text-transparent bg-gradient-to-b from-white to-neutral-500;
}

html.lenis,
html.lenis body {
  height: auto;
}

.lenis.lenis-smooth {
  scroll-behavior: auto !important;
}

@keyframes float {
  0% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0px); }
}

.animate-float {
  animation: float 4s ease-in-out infinite;
}

.glow-green {
  box-shadow: 0 0 20px rgba(34, 197, 94, 0.2);
}

.refinement-line {
  @apply absolute inset-6 md:inset-12 border border-white/5 pointer-events-none rounded-sm z-0;
}
```

### Archivo: `src/App.tsx`
```tsx
import { motion, AnimatePresence } from 'motion/react';
import { 
  Camera, Palette, Box, ChevronRight, ArrowRight, Instagram, Mail, 
  Layout, Fingerprint, Search, Menu, X, Play, Zap, Users, Target, 
  TrendingUp, Send, MessageCircle, ShieldCheck, Check
} from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import Lenis from 'lenis';
import { cn } from './lib/utils';

// --- Navbar ---
const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.nav className={cn("fixed top-0 left-0 right-0 z-[100] transition-all duration-500", isScrolled ? "py-4" : "py-8")}>
      <div className={cn("max-w-7xl mx-auto px-6 flex items-center justify-between", isScrolled ? "glass rounded-full py-3 px-8 mx-6" : "px-12")}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-white rounded-full flex items-center justify-center font-display font-black text-black text-xs">K</div>
          <span className="font-display font-bold text-2xl tracking-tighter">KOVE</span>
        </div>
        <div className="hidden lg:flex items-center gap-10 text-[11px] font-bold tracking-[0.2em] uppercase text-neutral-500">
          <a href="#home">Inicio</a><a href="#about">Estudio</a><a href="#portfolio">Proyectos</a><a href="#contact">Contacto</a>
        </div>
        <button className="px-6 py-2.5 bg-white text-black rounded-full text-xs font-bold hover:scale-105 transition-all">Let's Talk</button>
      </div>
    </motion.nav>
  );
};

// --- IA Assistant ---
const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="fixed bottom-8 right-8 z-[1000]">
      {isOpen && (
        <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} className="absolute bottom-20 right-0 w-80 glass rounded-[2rem] p-6 shadow-2xl">
          <div className="flex items-center gap-3 mb-6 border-b border-white/5 pb-4">
            <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center"><div className="w-4 h-4 bg-white rounded-full animate-pulse" /></div>
            <div><h4 className="text-sm font-bold">KOVE IA</h4><span className="text-[10px] text-green-500 font-bold uppercase tracking-widest">Online</span></div>
          </div>
          <div className="text-sm text-neutral-400 mb-6 leading-relaxed">Hola, soy la IA de KOVE. ¿Quieres elevar el nivel visual de tu marca hoy?</div>
          <button className="w-full py-3 bg-white text-black rounded-full font-bold text-xs uppercase">Hablar con IA</button>
        </motion.div>
      )}
      <button onClick={() => setIsOpen(!isOpen)} className="w-16 h-16 bg-white text-black rounded-full shadow-2xl flex items-center justify-center">
        {isOpen ? <X /> : <MessageCircle />}
      </button>
    </div>
  );
};

export default function App() {
  useEffect(() => {
    const lenis = new Lenis();
    function raf(time: number) { lenis.raf(time); requestAnimationFrame(raf); }
    requestAnimationFrame(raf);
    return () => lenis.destroy();
  }, []);

  return (
    <div className="bg-titanium min-h-screen relative overflow-x-hidden">
      <div className="refinement-line" />
      <Navbar />
      
      {/* Hero */}
      <section id="home" className="h-screen flex flex-col items-center justify-center text-center px-6">
        <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="font-display text-[100px] md:text-[220px] font-black tracking-[-0.08em] leading-none mb-12">KOVE</motion.h1>
        <p className="text-white/40 uppercase tracking-[0.5em] text-xs md:text-sm font-light mb-16">Diseño Gráfico • Branding • Dirección Creativa</p>
        <div className="flex gap-4">
          <button className="px-12 py-5 bg-white text-black rounded-full font-black text-xs uppercase tracking-widest shadow-2xl">Proyectos</button>
          <button className="px-12 py-5 glass rounded-full font-black text-xs uppercase tracking-widest">Contacto</button>
        </div>
      </section>

      {/* Services, Portfolio, etc. (Continuar con la misma lógica visual de KOVE) */}
      
      <AIAssistant />
    </div>
  );
}
```

## 3. Prompts de Generación de Imágenes
Usa estos prompts en un generador de imágenes (como Midjourney o DALL-E) para obtener los mismos assets:

1. **Poster Principal (Firma KOVE):**
   > "Professional graphic design poster. Large bold 'KOVE' text outlined in the background. A central cutout image of premium AirPods with a soft shadow. Clean white and dark gray sections. Ultra-minimalist, sleek, high-end Apple-style aesthetic. High resolution."

2. **Diseño Sushi (Baraca da Sushi):**
   > "High-quality graphic design poster for 'Baraca da Sushi'. Central plate of assorted sushi on a white background with a large bold red 'Sushi' vertical text. Modern, minimal, premium food photography style."

3. **Beverage Design (Blueberry):**
   > "Commercial graphic design for 'Blueberry Flavor Drink'. A purple aluminum can with condensation droplets. Floating fresh blueberries and green leaves. Vibrant, high-end beverage advertising."

4. **Event Poster (Wobble):**
   > "Modern event poster design 'EMPIRE' featuring 'DJ PHANTOM'. Large black bold 'WOBBLE' text repeating. High-contrast black and white aesthetic with grain texture. Professional event branding."

---
**Diseñado por el Agente de IA de KOVE. Cada detalle importa.**
