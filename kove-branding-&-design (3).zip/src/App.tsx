import { motion, AnimatePresence, useScroll, useTransform, useSpring } from 'motion/react';
import { 
  Camera, Palette, Box, ChevronRight, ArrowRight, Instagram, Mail, 
  Layout, Fingerprint, Search, Menu, X, Play, Zap, Users, Target, 
  TrendingUp, Send, MessageCircle, MoreHorizontal, Check, ShieldCheck
} from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import Lenis from 'lenis';
import { cn } from './lib/utils';
import heroImage from './assets/images/kove_premium_branding_1779031327139.png';
import blueberryImg from './assets/images/blueberry_drink_1779032457011.png';
import brownieImg from './assets/images/brownie_branding_1779032531145.png';
import coffeeImg from './assets/images/coffee_branding_1779032512840.png';
import cupcakeImg from './assets/images/cupcake_branding_1779032496859.png';
import empireImg from './assets/images/empire_wobble_event_1779032474521.png';
import sushiImg from './assets/images/sushi_branding_1779032438877.png';
import signatureImg from './assets/images/kove_signature_poster_1779032563945.png';

// --- Navbar Component ---
const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { name: 'Inicio', href: '#home' },
    { name: 'Sobre KOVE', href: '#about' },
    { name: 'Servicios', href: '#services' },
    { name: 'Portafolio', href: '#portfolio' },
    { name: 'Precios', href: '#pricing' },
    { name: 'Contacto', href: '#contact' },
  ];

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={cn(
        "fixed top-0 left-0 right-0 z-[100] transition-all duration-500",
        isScrolled ? "py-4" : "py-8"
      )}
    >
      <div className={cn(
        "max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between",
        isScrolled ? "glass rounded-full py-3 pr-4 pl-8" : ""
      )}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-white rounded-full flex items-center justify-center">
            <span className="text-black font-display font-black text-xs">K</span>
          </div>
          <span className="font-display font-bold tracking-tighter text-2xl">KOVE</span>
        </div>

        <div className="hidden lg:flex items-center gap-10">
          {menuItems.map((item) => (
            <a 
              key={item.name}
              href={item.href} 
              className="text-[11px] font-bold tracking-[0.2em] uppercase text-neutral-400 hover:text-white transition-colors"
            >
              {item.name}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <button className="hidden md:flex p-2 text-neutral-400 hover:text-white transition-colors">
            <Search size={20} />
          </button>
          <button className="px-6 py-2.5 bg-white text-black rounded-full text-xs font-bold hover:scale-105 transition-transform">
            Inicia Proyectos
          </button>
          <button 
            className="lg:hidden p-2 text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-6 right-6 mt-4 glass p-8 rounded-3xl lg:hidden flex flex-col gap-6"
          >
            {menuItems.map((item) => (
              <a 
                key={item.name}
                href={item.href} 
                onClick={() => setIsMenuOpen(false)}
                className="text-lg font-bold tracking-tight text-white/70 hover:text-white transition-colors"
              >
                {item.name}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

// --- Stats Section ---
const AnimatedStats = () => {
  const stats = [
    { label: "Clientes Satisfechos", value: "250+", icon: Users },
    { label: "Proyectos Realizados", value: "1.2k", icon: Check },
    { label: "Conversión Visual", value: "85%", icon: TrendingUp },
    { label: "Impacto de Marca", value: "10x", icon: Zap },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 px-6 max-w-7xl mx-auto -mt-12 z-20 relative">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          viewport={{ once: true }}
          className="glass p-8 rounded-[2.5rem] flex flex-col gap-4 group hover:bg-white/5 transition-all"
        >
          <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center group-hover:bg-green-500/20 group-hover:text-green-500 transition-all">
            <stat.icon size={20} />
          </div>
          <div>
            <h4 className="text-3xl font-display font-black group-hover:text-green-500 transition-colors">{stat.value}</h4>
            <p className="text-neutral-500 text-[10px] uppercase tracking-widest font-bold">{stat.label}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

// --- Services Grid ---
const ServicesSection = () => {
  const services = [
    { title: "Diseño Gráfico", desc: "Estética visual minimalista y funcional.", icon: Palette },
    { title: "Edición de Video", desc: "Nativa cinematográfica de alto impacto.", icon: Camera },
    { title: "Motion Graphics", desc: "Animaciones fluidas y futuristas.", icon: Play },
    { title: "Branding", desc: "Identidad completa para marcas premium.", icon: Fingerprint },
    { title: "E-Commerce", desc: "Optimización visual para ventas masivas.", icon: Zap },
    { title: "Dropshipping", desc: "Diseño estratégico para nichos globales.", icon: Target },
    { title: "Identidad de Marca", desc: "Sistemas de diseño editorial moderno.", icon: Layout },
    { title: "Dirección Visual", desc: "Dirección creativa de alto nivel.", icon: Box },
  ];

  return (
    <section id="services" className="py-32 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col items-center text-center mb-24">
        <span className="text-neutral-600 font-mono text-[10px] tracking-[0.5em] uppercase mb-4">Experiencia Profesional</span>
        <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tight mb-6">
          Servicios <span className="text-neutral-500">Premium</span>
        </h2>
        <div className="h-px w-24 bg-white/20" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {services.map((service, i) => (
          <motion.div
            key={service.title}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.05 }}
            viewport={{ once: true }}
            className="group relative p-8 glass rounded-[2.5rem] overflow-hidden hover:bg-white/5 transition-all overflow-hidden"
          >
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-white/5 blur-[40px] group-hover:bg-white/10 transition-all rounded-full" />
            <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <service.icon size={24} />
            </div>
            <h3 className="text-xl font-bold mb-3 tracking-tight">{service.title}</h3>
            <p className="text-neutral-500 text-sm leading-relaxed">{service.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

// --- AI Assistant ---
const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: 'ai', text: 'Hola, soy el asistente IA de KOVE. ¿En qué puedo ayudarte hoy?' }
  ]);
  const [inputValue, setInputValue] = useState('');

  const handleSend = () => {
    if (!inputValue.trim()) return;
    setMessages([...messages, { role: 'user', text: inputValue }]);
    setInputValue('');
    
    // Simulate AI response
    setTimeout(() => {
      setMessages(prev => [...prev, { 
        role: 'ai', 
        text: '¡Entendido! Puedo ayudarte con cotizaciones, servicios o mostrarte nuestro portafolio. ¿Te gustaría ver los planes de precios?' 
      }]);
    }, 1000);
  };

  return (
    <div className="fixed bottom-8 right-8 z-[1000]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            className="absolute bottom-20 right-0 w-[350px] max-w-[calc(100vw-4rem)] glass rounded-[2.5rem] overflow-hidden shadow-2xl"
          >
            <div className="p-6 bg-white/5 border-b border-white/5 flex items-center gap-3">
              <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center overflow-hidden">
                <motion.div 
                  animate={{ y: [0, -2, 0] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="w-4 h-8 bg-white rounded-full opacity-80"
                />
              </div>
              <div>
                <h4 className="font-bold text-sm">KOVE IA</h4>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-[10px] text-neutral-500 uppercase font-bold tracking-widest">En línea</span>
                </div>
              </div>
            </div>

            <div className="h-[400px] overflow-y-auto p-6 flex flex-col gap-4 scroll-smooth">
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: msg.role === 'ai' ? -10 : 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={cn(
                    "max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed",
                    msg.role === 'ai' 
                      ? "bg-white/5 text-neutral-300 self-start rounded-tl-none" 
                      : "bg-white text-black self-end rounded-tr-none font-medium"
                  )}
                >
                  {msg.text}
                </motion.div>
              ))}
            </div>

            <div className="p-4 border-t border-white/5">
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Escribe tu mensaje..."
                  className="flex-1 bg-white/5 border border-white/10 rounded-full px-4 py-2 text-xs outline-none focus:border-white/20 transition-all"
                />
                <button 
                  onClick={handleSend}
                  className="w-10 h-10 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 transition-transform"
                >
                  <Send size={16} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-16 h-16 bg-white text-black rounded-full shadow-2xl flex items-center justify-center overflow-hidden group"
      >
        {isOpen ? <X /> : (
          <div className="relative">
            <MessageCircle className="group-hover:opacity-0 transition-opacity" />
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="w-1.5 h-4 bg-black rounded-full mr-0.5" />
              <div className="w-1.5 h-4 bg-black rounded-full" />
            </div>
          </div>
        )}
      </motion.button>
    </div>
  );
};

// --- Pricing Section ---
const PricingSection = () => {
  const plans = [
    {
      name: "Starter",
      price: "$299",
      features: ["Diseño básico", "2 Piezas gráficas", "Entrega rápida (48h)", "Soporte estándar"],
      highlight: false
    },
    {
      name: "Premium",
      price: "$799",
      features: ["Branding Completo", "Motion Graphics", "Diseños Premium", "Estrategia Visual", "2 Revisiones"],
      highlight: true
    },
    {
      name: "Elite",
      price: "$1,499",
      features: ["Dirección Creativa", "Gestión Mensual", "Identidad Completa", "Contenido Elite", "Soporte 24/7"],
      highlight: false
    }
  ];

  return (
    <section id="pricing" className="py-32 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col items-center text-center mb-24">
        <span className="text-neutral-600 font-mono text-[10px] tracking-[0.5em] uppercase mb-4">Inversión Visual</span>
        <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tight mb-6">Planes de <span className="text-neutral-500">Diseño</span></h2>
        <div className="h-px w-24 bg-white/20" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan, i) => (
          <motion.div
            key={plan.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
            className={cn(
              "glass p-12 rounded-[3.5rem] flex flex-col gap-8 relative overflow-hidden group",
              plan.highlight && "border-green-500/20 glow-green"
            )}
          >
            {plan.highlight && (
              <div className="absolute top-6 right-8 px-4 py-1.5 bg-green-500 text-black text-[10px] font-black uppercase tracking-widest rounded-full">
                Más Popular
              </div>
            )}
            <div className="flex flex-col gap-2">
              <span className="text-neutral-500 text-xs font-bold uppercase tracking-widest">{plan.name}</span>
              <h4 className="text-5xl font-display font-black tracking-tighter">{plan.price}</h4>
              <span className="text-neutral-600 text-[10px] uppercase font-bold">Pago único o mensual</span>
            </div>
            
            <div className="flex flex-col gap-4">
              {plan.features.map(f => (
                <div key={f} className="flex items-center gap-3 text-sm text-neutral-400">
                  <ShieldCheck size={16} className={plan.highlight ? "text-green-500" : "text-neutral-600"} />
                  {f}
                </div>
              ))}
            </div>

            <button className={cn(
              "w-full py-4 rounded-full font-bold text-xs uppercase tracking-widest transition-all",
              plan.highlight ? "bg-white text-black scale-105 hover:bg-green-500" : "bg-white/5 border border-white/10 hover:bg-white hover:text-black"
            )}>
              Elegir Plan
            </button>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

// --- Portfolio Section ---
const PortfolioSection = () => {
  const projects = [
    { 
      title: "Empire: Wobble Event", 
      cat: "Poster Design", 
      img: empireImg,
      desc: "Tipografía experimental y composición dinámica para eventos."
    },
    { 
      title: "Baraca da Sushi", 
      cat: "Editorial Branding", 
      img: sushiImg,
      desc: "Identidad visual minimalista con alto contraste cromático."
    },
    { 
      title: "Cupcake Harmony", 
      cat: "Product Design", 
      img: cupcakeImg,
      desc: "Packaging y diseño de producto con enfoque premium."
    },
    { 
      title: "Borcelle Bakery", 
      cat: "Brand Identity", 
      img: brownieImg,
      desc: "Sistemas visuales cohesivos para repostería artesanal."
    },
    { 
      title: "Best Coffee Ever", 
      cat: "Digital Content", 
      img: coffeeImg,
      desc: "Creación de contenido visual para redes y marketing."
    },
    { 
      title: "Blueberry Fresh", 
      cat: "Advertising", 
      img: blueberryImg,
      desc: "Visuales publicitarios de alto impacto para gran consumo."
    },
  ];

  return (
    <section id="portfolio" className="py-32 px-6 bg-black/40 relative">
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-titanium to-transparent z-10" />
      <div className="max-w-7xl mx-auto relative z-20">
        <div className="flex flex-col md:flex-row justify-between items-end mb-24 gap-8">
          <div>
            <span className="text-neutral-600 font-mono text-[10px] tracking-[0.5em] uppercase mb-4">Portafolio Seleccionado</span>
            <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tight">Showcase <span className="text-neutral-500">Elite</span></h2>
          </div>
          <button className="flex items-center gap-2 group text-xs font-bold uppercase tracking-widest text-neutral-500 hover:text-white transition-colors">
            Ver Portafolio Completo <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="relative group cursor-pointer aspect-[4/5] overflow-hidden rounded-[3rem] border border-white/5 bg-white/2"
            >
              <img 
                src={p.img} 
                alt={p.title} 
                className="w-full h-full object-cover grayscale brightness-75 group-hover:scale-105 group-hover:grayscale-0 group-hover:brightness-100 transition-all duration-1000 ease-[0.16,1,0.3,1]"
              />
              {/* Refined Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />
              
              <div className="absolute bottom-10 left-10 right-10 text-white translate-y-4 group-hover:translate-y-0 transition-all duration-500">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-1.5 h-1.5 bg-white rounded-full group-hover:scale-150 transition-transform" />
                  <span className="text-[10px] uppercase tracking-widest font-black text-white/40 group-hover:text-white">{p.cat}</span>
                </div>
                <h4 className="text-2xl font-display font-black tracking-tighter mb-2">{p.title}</h4>
                <p className="text-xs text-white/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500 line-clamp-1">{p.desc}</p>
              </div>

              <div className="absolute top-10 right-10 opacity-0 group-hover:opacity-100 transition-all scale-75 group-hover:scale-100">
                <div className="w-14 h-14 glass rounded-full flex items-center justify-center">
                  <ArrowRight size={24} className="-rotate-45" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// --- Contact Section ---
const ContactSection = () => {
  return (
    <section id="contact" className="py-32 px-6 max-w-4xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="glass p-16 rounded-[4rem] relative overflow-hidden"
      >
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-white/5 rounded-full blur-[100px]" />
        
        <div className="flex flex-col items-center text-center mb-16">
          <span className="text-neutral-600 font-mono text-[10px] tracking-[0.5em] uppercase mb-4">¿Hablamos?</span>
          <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tight mb-4">Inicia tu <span className="text-neutral-500">Visión</span></h2>
          <p className="text-neutral-400 max-w-sm">Estamos listos para elevar el estándar visual de tu próximo proyecto.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="flex flex-col gap-2">
            <label className="text-[10px] uppercase tracking-widest font-bold text-neutral-500 ml-4">Nombre</label>
            <input type="text" placeholder="John Doe" className="bg-white/5 border border-white/10 rounded-2xl p-4 outline-none focus:border-white transition-all" />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-[10px] uppercase tracking-widest font-bold text-neutral-500 ml-4">Email</label>
            <input type="email" placeholder="john@company.com" className="bg-white/5 border border-white/10 rounded-2xl p-4 outline-none focus:border-white transition-all" />
          </div>
        </div>

        <div className="flex flex-col gap-2 mb-12">
          <label className="text-[10px] uppercase tracking-widest font-bold text-neutral-500 ml-4">Tu Proyecto</label>
          <textarea rows={4} placeholder="Cuéntanos un poco sobre tus ideas..." className="bg-white/5 border border-white/10 rounded-3xl p-6 outline-none focus:border-white transition-all resize-none"></textarea>
        </div>

        <button className="w-full py-6 bg-white text-black rounded-full font-black text-xs uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-2xl">
          Enviar Propuesta
        </button>

        <div className="mt-12 pt-12 border-t border-white/5 flex flex-wrap justify-center gap-8">
          <a href="#" className="flex items-center gap-2 text-neutral-500 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest">
            <Instagram size={18} /> Instagram
          </a>
          <a href="#" className="flex items-center gap-2 text-neutral-500 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest">
            <Mail size={18} /> Email
          </a>
          <a href="#" className="flex items-center gap-2 text-neutral-500 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest">
             WhatsApp
          </a>
        </div>
      </motion.div>
    </section>
  );
};

export default function App() {
  const containerRef = useRef(null);

  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1,
      infinite: false,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <div className="bg-titanium selection:bg-white selection:text-black min-h-screen relative overflow-x-hidden">
      <div className="refinement-line" />
      <Navbar />
      
      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex flex-col items-center justify-center pt-24 px-6 text-center overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-white opacity-[0.03] blur-[150px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-white opacity-[0.03] blur-[150px] rounded-full" />
        
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
          className="z-10 w-full max-w-6xl relative"
        >
          <div className="relative mb-8">
            <motion.h1 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1.2 }}
              className="font-display text-[100px] md:text-[220px] font-black tracking-[-0.08em] leading-[0.8] text-white drop-shadow-[0_20px_40px_rgba(255,255,255,0.05)]"
            >
              KOVE
            </motion.h1>
          </div>
          
          <div className="h-[2px] w-32 bg-gradient-to-r from-transparent via-white/40 to-transparent mx-auto my-12" />

          <p className="max-w-2xl mx-auto text-sm md:text-lg tracking-[0.4em] font-light text-white/50 uppercase mb-20 leading-relaxed">
            Especialista en Diseño Gráfico • Branding Editorial • Dirección Creativa
          </p>

          <div className="flex flex-col md:flex-row items-center justify-center gap-6">
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              className="px-12 py-5 bg-white text-black rounded-full font-black text-xs uppercase tracking-[0.2em] transition-all shadow-2xl relative overflow-hidden group"
            >
              <span className="relative z-10">Explora el portafolio</span>
              <div className="absolute inset-0 bg-neutral-200 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
            </motion.button>
            <button className="px-12 py-5 border border-white/20 rounded-full font-black text-xs uppercase tracking-[0.2em] bg-white/5 backdrop-blur-md hover:bg-white/10 transition-all flex items-center gap-3">
              Contactar Ahora <ArrowRight size={16} />
            </button>
          </div>
        </motion.div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 opacity-30">
          <span className="text-[10px] uppercase font-bold tracking-[0.5em] rotate-90">Scroll</span>
          <div className="h-12 w-px bg-white/40 animate-pulse" />
        </div>
      </section>

      <AnimatedStats />

      {/* About Section */}
      <section id="about" className="py-48 px-6 relative overflow-hidden">
        <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-white/5 blur-[120px] rounded-full -translate-y-1/2" />
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex flex-col gap-8"
          >
            <span className="text-neutral-600 font-mono text-[10px] tracking-[0.5em] uppercase">Filosofía KOVE</span>
            <h2 className="font-display text-5xl md:text-7xl font-bold tracking-tight leading-[0.9]">
              Donde la <span className="text-neutral-500">precisión</span> se encuentra con la <span className="text-white">elegancia.</span>
            </h2>
            <p className="text-neutral-400 text-lg leading-relaxed font-light max-w-xl">
              KOVE no es solo un estudio; es un laboratorio de estética moderna. Nos enfocamos en la dirección visual cinematográfica, el branding minimalista y la edición profesional de alto impacto. 
              <br /><br />
              Creemos que cada píxel tiene un propósito. Nuestra misión es eliminar el ruido visual para dejar que la esencia de tu marca brille con autoridad y sofisticación.
            </p>
            <div className="flex gap-12 mt-4">
              <div>
                <p className="text-2xl font-display font-black text-white">99%</p>
                <p className="text-[10px] uppercase tracking-widest text-neutral-600 font-bold">Precisión Visual</p>
              </div>
              <div>
                <p className="text-2xl font-display font-black text-white">2.5k</p>
                <p className="text-[10px] uppercase tracking-widest text-neutral-600 font-bold">Horas de Edición</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-white/5 blur-3xl opacity-30" />
            <div className="relative rounded-[4rem] overflow-hidden border border-white/5 shadow-2xl glass aspect-square lg:aspect-auto">
              <img 
                src={signatureImg} 
                alt="Workspace" 
                className="w-full h-full object-cover grayscale brightness-75 hover:grayscale-0 hover:brightness-100 transition-all duration-1000"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
              <div className="absolute bottom-12 left-12">
                <span className="text-[10px] font-black uppercase tracking-widest text-white/40 mb-2 block">Portfolio Keypiece</span>
                <p className="text-2xl font-display font-black">KOVEDESIGN© 2024</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <ServicesSection />
      <PortfolioSection />
      <PricingSection />

      {/* Quote Section */}
      <section className="py-40 relative flex items-center justify-center overflow-hidden bg-white text-black">
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
          className="z-10 text-center px-6"
        >
          <span className="text-[10px] uppercase font-bold tracking-[0.5em] opacity-40 mb-8 block">Nuestra Promesa</span>
          <h2 className="font-display text-4xl md:text-9xl font-black tracking-tighter leading-none mb-12">
            CADA DETALLE IMPORTA.
          </h2>
          <div className="h-px w-32 bg-black/10 mx-auto" />
        </motion.div>
      </section>

      <ContactSection />
      
      <footer className="py-24 px-8 md:px-16 border-t border-white/5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start gap-16 mb-24">
          <div className="flex flex-col gap-8 max-w-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                <span className="text-black font-display font-black text-sm">K</span>
              </div>
              <span className="font-display font-bold tracking-tighter text-2xl uppercase text-white">KOVE</span>
            </div>
            <p className="text-neutral-500 font-light leading-relaxed">
              Elevando el estándar visual para marcas modernas a través de la precisión cinematográfica y el minimalismo editorial.
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-3 gap-16">
            <div className="flex flex-col gap-6">
              <h5 className="text-[10px] uppercase font-bold tracking-widest text-white/40">Studio</h5>
              <a href="#" className="text-sm text-neutral-400 hover:text-white transition-colors">Proyectos</a>
              <a href="#" className="text-sm text-neutral-400 hover:text-white transition-colors">Historia</a>
              <a href="#" className="text-sm text-neutral-400 hover:text-white transition-colors">Equipo</a>
            </div>
            <div className="flex flex-col gap-6">
              <h5 className="text-[10px] uppercase font-bold tracking-widest text-white/40">Conectar</h5>
              <a href="#" className="text-sm text-neutral-400 hover:text-white transition-colors">Instagram</a>
              <a href="#" className="text-sm text-neutral-400 hover:text-white transition-colors">LinkedIn</a>
              <a href="#" className="text-sm text-neutral-400 hover:text-white transition-colors">Dribbble</a>
            </div>
            <div className="hidden lg:flex flex-col gap-6">
              <h5 className="text-[10px] uppercase font-bold tracking-widest text-white/40">Newsletter</h5>
              <div className="flex gap-2">
                <input type="text" placeholder="Email" className="bg-white/5 border border-white/10 rounded-full px-4 py-2 text-xs outline-none w-32 focus:w-48 transition-all" />
                <button className="w-10 h-10 bg-white text-black rounded-full flex items-center justify-center"><ArrowRight size={16} /></button>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-[10px] text-white/20 font-mono uppercase tracking-[0.4em] gap-8">
          <span>v.2.0.4 — © 2024 KOVEDESIGN — BUILT WITH PRECISION</span>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white/50 transition-colors">Privacidad</a>
            <a href="#" className="hover:text-white/50 transition-colors">Términos</a>
          </div>
        </div>
      </footer>

      <AIAssistant />
    </div>
  );
}

